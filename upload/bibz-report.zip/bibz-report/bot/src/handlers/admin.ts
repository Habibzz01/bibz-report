import type { BotContext } from '../bot.js';
import * as db from '../utils/db.js';
import { escapeHtml, formatDuration } from '../utils/format.js';
import { logEmitter } from '../middleware/logger.js';

function getSuperAdminId(): string {
  return process.env.SUPER_ADMIN_ID ?? '';
}

async function isSuperAdmin(ctx: BotContext): Promise<boolean> {
  const userId = ctx.from?.id;
  return String(userId) === getSuperAdminId();
}

async function isAdminOrSuper(ctx: BotContext): Promise<boolean> {
  if (await isSuperAdmin(ctx)) return true;
  const userId = String(ctx.from?.id ?? '');
  const admin = await db.getAdmin(userId);
  return admin !== null;
}

export async function addAdminHandler(ctx: BotContext): Promise<void> {
  try {
    if (!(await isSuperAdmin(ctx))) {
      await ctx.reply('❌ Hanya super admin yang bisa menambah admin.');
      return;
    }

    const targetId = (ctx.match as string)?.trim();
    if (!targetId) {
      await ctx.reply('❌ Gunakan: /addadmin <telegram_id>');
      return;
    }

    await db.addAdmin(targetId, null, String(ctx.from?.id ?? ''));
    await ctx.reply(`✅ Admin ${escapeHtml(targetId)} berhasil ditambahkan.`);
    logEmitter.emit('log', {
      timestamp: new Date().toISOString(),
      type: 'info',
      text: `Admin added: ${targetId}`,
    });
  } catch (error) {
    await ctx.reply('❌ Gagal menambah admin.');
    logEmitter.emit('log', {
      timestamp: new Date().toISOString(),
      type: 'error',
      text: `addAdmin error: ${error instanceof Error ? error.message : 'Unknown'}`,
    });
  }
}

export async function listAdminHandler(ctx: BotContext): Promise<void> {
  try {
    if (!(await isAdminOrSuper(ctx))) {
      await ctx.reply('❌ Kamu tidak memiliki akses.');
      return;
    }

    const admins = await db.getAllAdmins();
    if (admins.length === 0) {
      await ctx.reply('📋 Belum ada admin.');
      return;
    }

    const superId = getSuperAdminId();
    let text = '<b>👑 Daftar Admin:</b>\n\n';
    text += `• Super Admin: <code>${superId}</code>\n`;

    for (const admin of admins) {
      const username = admin.telegram_username
        ? `@${admin.telegram_username}`
        : '-';
      text += `• <code>${admin.telegram_id}</code> (${username}) - added by ${admin.added_by}\n`;
    }

    await ctx.reply(text, { parse_mode: 'HTML' });
  } catch (error) {
    await ctx.reply('❌ Gagal mengambil daftar admin.');
    logEmitter.emit('log', {
      timestamp: new Date().toISOString(),
      type: 'error',
      text: `listAdmin error: ${error instanceof Error ? error.message : 'Unknown'}`,
    });
  }
}

export async function unAdminHandler(ctx: BotContext): Promise<void> {
  try {
    if (!(await isSuperAdmin(ctx))) {
      await ctx.reply('❌ Hanya super admin yang bisa menghapus admin.');
      return;
    }

    const targetId = (ctx.match as string)?.trim();
    if (!targetId) {
      await ctx.reply('❌ Gunakan: /unadmin <telegram_id>');
      return;
    }

    await db.removeAdmin(targetId);
    await ctx.reply(`✅ Admin ${escapeHtml(targetId)} berhasil dihapus.`);
    logEmitter.emit('log', {
      timestamp: new Date().toISOString(),
      type: 'info',
      text: `Admin removed: ${targetId}`,
    });
  } catch (error) {
    await ctx.reply('❌ Gagal menghapus admin.');
    logEmitter.emit('log', {
      timestamp: new Date().toISOString(),
      type: 'error',
      text: `unAdmin error: ${error instanceof Error ? error.message : 'Unknown'}`,
    });
  }
}

function parseUsername(text: string): { username: string } | null {
  const trimmed = text.trim();
  if (trimmed.startsWith('@')) {
    return { username: trimmed.slice(1) };
  }
  return null;
}

export async function kickHandler(ctx: BotContext): Promise<void> {
  try {
    if (!(await isAdminOrSuper(ctx))) {
      await ctx.reply('❌ Kamu tidak memiliki akses.');
      return;
    }

    const arg = ctx.match as string;
    if (!arg) {
      await ctx.reply('❌ Gunakan: /kick @username');
      return;
    }

    const parsed = parseUsername(arg);
    if (!parsed) {
      await ctx.reply('❌ Gunakan: /kick @username');
      return;
    }

    const chatId = ctx.chat?.id;
    if (!chatId) return;

    try {
      const chat = await ctx.getChat();
      const members = await ctx.api.getChatAdministrators(chatId);
      const target = members.find(
        (m) => m.user.username?.toLowerCase() === parsed.username.toLowerCase()
      );

      if (target) {
        await ctx.api.kickChatMember(chatId, target.user.id);
        await db.addModAction('kick', String(target.user.id), String(ctx.from?.id ?? ''), null);
        await ctx.reply(`✅ Berhasil meng-kick @${parsed.username}`);
        logEmitter.emit('log', {
          timestamp: new Date().toISOString(),
          type: 'kick',
          text: `${ctx.from?.username ?? ctx.from?.first_name} kicked @${parsed.username}`,
        });
      } else {
        await ctx.reply('❌ User tidak ditemukan di grup ini.');
      }
    } catch {
      await ctx.reply('❌ Gagal meng-kick user. Pastikan bot punya hak admin.');
    }
  } catch (error) {
    logEmitter.emit('log', {
      timestamp: new Date().toISOString(),
      type: 'error',
      text: `kick error: ${error instanceof Error ? error.message : 'Unknown'}`,
    });
  }
}

export async function muteHandler(ctx: BotContext): Promise<void> {
  try {
    if (!(await isAdminOrSuper(ctx))) {
      await ctx.reply('❌ Kamu tidak memiliki akses.');
      return;
    }

    const args = (ctx.match as string)?.trim().split(/\s+/);
    if (!args || args.length < 1) {
      await ctx.reply('❌ Gunakan: /mute @username [duration] (30m, 1h, 6h, 24h, forever)');
      return;
    }

    const parsedUser = parseUsername(args[0]);
    if (!parsedUser) {
      await ctx.reply('❌ Gunakan: /mute @username [duration]');
      return;
    }

    let durationMinutes = 60;
    if (args.length > 1) {
      const durStr = args[1].toLowerCase();
      if (durStr === 'forever') {
        durationMinutes = 0;
      } else if (durStr.endsWith('h')) {
        durationMinutes = parseInt(durStr, 10) * 60;
      } else if (durStr.endsWith('m')) {
        durationMinutes = parseInt(durStr, 10);
      } else if (durStr.endsWith('d')) {
        durationMinutes = parseInt(durStr, 10) * 1440;
      } else {
        durationMinutes = parseInt(durStr, 10) || 60;
      }
    }

    const chatId = ctx.chat?.id;
    if (!chatId) return;

    try {
      const chat = await ctx.getChat();
      const members = await ctx.api.getChatAdministrators(chatId);
      const target = members.find(
        (m) => m.user.username?.toLowerCase() === parsedUser.username.toLowerCase()
      );

      if (target) {
        const permissions = {
          can_send_messages: false,
          can_send_media_messages: false,
          can_send_polls: false,
          can_send_other_messages: false,
          can_add_web_page_previews: false,
          can_change_info: false,
          can_invite_users: false,
          can_pin_messages: false,
        };

        if (durationMinutes > 0) {
          const untilDate = Math.floor(Date.now() / 1000) + durationMinutes * 60;
          await ctx.api.restrictChatMember(chatId, target.user.id, {
            ...permissions,
            until_date: untilDate,
          });
          const durText = formatDuration(durationMinutes);
          await ctx.reply(`✅ @${parsedUser.username} dimute selama ${durText}`);
        } else {
          await ctx.api.restrictChatMember(chatId, target.user.id, permissions);
          await ctx.reply(`✅ @${parsedUser.username} dimute selamanya`);
        }

        await db.addModAction('mute', String(target.user.id), String(ctx.from?.id ?? ''), null);
        logEmitter.emit('log', {
          timestamp: new Date().toISOString(),
          type: 'mute',
          text: `${ctx.from?.username ?? ctx.from?.first_name} muted @${parsedUser.username}`,
        });
      } else {
        await ctx.reply('❌ User tidak ditemukan di grup ini.');
      }
    } catch {
      await ctx.reply('❌ Gagal memute user. Pastikan bot punya hak admin.');
    }
  } catch (error) {
    logEmitter.emit('log', {
      timestamp: new Date().toISOString(),
      type: 'error',
      text: `mute error: ${error instanceof Error ? error.message : 'Unknown'}`,
    });
  }
}

export async function unmuteHandler(ctx: BotContext): Promise<void> {
  try {
    if (!(await isAdminOrSuper(ctx))) {
      await ctx.reply('❌ Kamu tidak memiliki akses.');
      return;
    }

    const arg = ctx.match as string;
    if (!arg) {
      await ctx.reply('❌ Gunakan: /unmute @username');
      return;
    }

    const parsed = parseUsername(arg);
    if (!parsed) {
      await ctx.reply('❌ Gunakan: /unmute @username');
      return;
    }

    const chatId = ctx.chat?.id;
    if (!chatId) return;

    try {
      const chat = await ctx.getChat();
      const members = await ctx.api.getChatAdministrators(chatId);
      const target = members.find(
        (m) => m.user.username?.toLowerCase() === parsed.username.toLowerCase()
      );

      if (target) {
        await ctx.api.restrictChatMember(chatId, target.user.id, {
          can_send_messages: true,
          can_send_media_messages: true,
          can_send_polls: true,
          can_send_other_messages: true,
          can_add_web_page_previews: true,
          can_change_info: true,
          can_invite_users: true,
          can_pin_messages: true,
        });
        await ctx.reply(`✅ @${parsed.username} berhasil di-unmute`);
      } else {
        await ctx.reply('❌ User tidak ditemukan di grup ini.');
      }
    } catch {
      await ctx.reply('❌ Gagal meng-unmute user.');
    }
  } catch (error) {
    logEmitter.emit('log', {
      timestamp: new Date().toISOString(),
      type: 'error',
      text: `unmute error: ${error instanceof Error ? error.message : 'Unknown'}`,
    });
  }
}

export async function banHandler(ctx: BotContext): Promise<void> {
  try {
    if (!(await isAdminOrSuper(ctx))) {
      await ctx.reply('❌ Kamu tidak memiliki akses.');
      return;
    }

    const arg = ctx.match as string;
    if (!arg) {
      await ctx.reply('❌ Gunakan: /ban @username');
      return;
    }

    const parsed = parseUsername(arg);
    if (!parsed) {
      await ctx.reply('❌ Gunakan: /ban @username');
      return;
    }

    const chatId = ctx.chat?.id;
    if (!chatId) return;

    try {
      const chat = await ctx.getChat();
      const members = await ctx.api.getChatAdministrators(chatId);
      const target = members.find(
        (m) => m.user.username?.toLowerCase() === parsed.username.toLowerCase()
      );

      if (target) {
        await ctx.api.banChatMember(chatId, target.user.id);
        await db.addModAction('ban', String(target.user.id), String(ctx.from?.id ?? ''), null);
        await ctx.reply(`✅ @${parsed.username} berhasil di-ban`);
        logEmitter.emit('log', {
          timestamp: new Date().toISOString(),
          type: 'ban',
          text: `${ctx.from?.username ?? ctx.from?.first_name} banned @${parsed.username}`,
        });
      } else {
        await ctx.reply('❌ User tidak ditemukan di grup ini.');
      }
    } catch {
      await ctx.reply('❌ Gagal me-ban user.');
    }
  } catch (error) {
    logEmitter.emit('log', {
      timestamp: new Date().toISOString(),
      type: 'error',
      text: `ban error: ${error instanceof Error ? error.message : 'Unknown'}`,
    });
  }
}

export async function unbanHandler(ctx: BotContext): Promise<void> {
  try {
    if (!(await isAdminOrSuper(ctx))) {
      await ctx.reply('❌ Kamu tidak memiliki akses.');
      return;
    }

    const arg = ctx.match as string;
    if (!arg) {
      await ctx.reply('❌ Gunakan: /unban @username');
      return;
    }

    const parsed = parseUsername(arg);
    if (!parsed) {
      await ctx.reply('❌ Gunakan: /unban @username');
      return;
    }

    const chatId = ctx.chat?.id;
    if (!chatId) return;

    try {
      const chat = await ctx.getChat();
      const members = await ctx.api.getChatAdministrators(chatId);
      const target = members.find(
        (m) => m.user.username?.toLowerCase() === parsed.username.toLowerCase()
      );

      if (target) {
        await ctx.api.unbanChatMember(chatId, target.user.id);
        await ctx.reply(`✅ @${parsed.username} berhasil di-unban`);
      } else {
        await ctx.reply('❌ User tidak ditemukan.');
      }
    } catch {
      await ctx.reply('❌ Gagal meng-unban user.');
    }
  } catch (error) {
    logEmitter.emit('log', {
      timestamp: new Date().toISOString(),
      type: 'error',
      text: `unban error: ${error instanceof Error ? error.message : 'Unknown'}`,
    });
  }
}

export async function warnHandler(ctx: BotContext): Promise<void> {
  try {
    if (!(await isAdminOrSuper(ctx))) {
      await ctx.reply('❌ Kamu tidak memiliki akses.');
      return;
    }

    const text = (ctx.match as string)?.trim();
    if (!text) {
      await ctx.reply('❌ Gunakan: /warn @username [reason]');
      return;
    }

    const parts = text.split(/\s+/);
    const parsedUser = parseUsername(parts[0]);
    if (!parsedUser) {
      await ctx.reply('❌ Gunakan: /warn @username [reason]');
      return;
    }

    const reason = parts.slice(1).join(' ') || null;
    const chatId = ctx.chat?.id;
    if (!chatId) return;

    try {
      const members = await ctx.api.getChatAdministrators(chatId);
      const target = members.find(
        (m) => m.user.username?.toLowerCase() === parsedUser.username.toLowerCase()
      );

      if (!target) {
        await ctx.reply('❌ User tidak ditemukan di grup ini.');
        return;
      }

      const adminId = String(ctx.from?.id ?? '');
      await db.addWarning(String(target.user.id), reason, adminId);
      const warnings = await db.getWarnings(String(target.user.id));

      if (warnings.length >= 3) {
        await ctx.api.kickChatMember(chatId, target.user.id);
        await db.addModAction('ban', String(target.user.id), adminId, '3 warnings otomatis');
        await ctx.reply(`⚠️ @${parsedUser.username} mendapat warn #3 dan otomatis di-ban!`);
      } else {
        await ctx.reply(`⚠️ @${parsedUser.username} diwarn (${warnings.length}/3)`);
      }

      await db.addModAction('warn', String(target.user.id), adminId, reason);
      logEmitter.emit('log', {
        timestamp: new Date().toISOString(),
        type: 'warning',
        text: `${ctx.from?.username ?? ctx.from?.first_name} warned @${parsedUser.username}: ${reason ?? 'no reason'}`,
      });
    } catch {
      await ctx.reply('❌ Gagal memberi warning.');
    }
  } catch (error) {
    logEmitter.emit('log', {
      timestamp: new Date().toISOString(),
      type: 'error',
      text: `warn error: ${error instanceof Error ? error.message : 'Unknown'}`,
    });
  }
}

export async function warningsHandler(ctx: BotContext): Promise<void> {
  try {
    if (!(await isAdminOrSuper(ctx))) {
      await ctx.reply('❌ Kamu tidak memiliki akses.');
      return;
    }

    const arg = ctx.match as string;
    if (!arg) {
      await ctx.reply('❌ Gunakan: /warnings @username');
      return;
    }

    const parsed = parseUsername(arg);
    if (!parsed) {
      await ctx.reply('❌ Gunakan: /warnings @username');
      return;
    }

    const chatId = ctx.chat?.id;
    if (!chatId) return;

    try {
      const members = await ctx.api.getChatAdministrators(chatId);
      const target = members.find(
        (m) => m.user.username?.toLowerCase() === parsed.username.toLowerCase()
      );

      if (!target) {
        await ctx.reply('❌ User tidak ditemukan.');
        return;
      }

      const warnings = await db.getWarnings(String(target.user.id));
      let text = `<b>⚠️ Warnings @${parsed.username}:</b> ${warnings.length}/3\n`;
      for (const w of warnings) {
        text += `• ${w.warned_at}: ${w.reason ?? 'no reason'} (by ${w.warned_by})\n`;
      }
      await ctx.reply(text, { parse_mode: 'HTML' });
    } catch {
      await ctx.reply('❌ Gagal mengambil data warnings.');
    }
  } catch (error) {
    logEmitter.emit('log', {
      timestamp: new Date().toISOString(),
      type: 'error',
      text: `warnings error: ${error instanceof Error ? error.message : 'Unknown'}`,
    });
  }
}

export async function clearWarnHandler(ctx: BotContext): Promise<void> {
  try {
    if (!(await isAdminOrSuper(ctx))) {
      await ctx.reply('❌ Kamu tidak memiliki akses.');
      return;
    }

    const arg = ctx.match as string;
    if (!arg) {
      await ctx.reply('❌ Gunakan: /clearwarn @username');
      return;
    }

    const parsed = parseUsername(arg);
    if (!parsed) {
      await ctx.reply('❌ Gunakan: /clearwarn @username');
      return;
    }

    const chatId = ctx.chat?.id;
    if (!chatId) return;

    try {
      const members = await ctx.api.getChatAdministrators(chatId);
      const target = members.find(
        (m) => m.user.username?.toLowerCase() === parsed.username.toLowerCase()
      );

      if (!target) {
        await ctx.reply('❌ User tidak ditemukan.');
        return;
      }

      await db.clearWarnings(String(target.user.id));
      await ctx.reply(`✅ Semua warning @${parsed.username} berhasil dibersihkan.`);
    } catch {
      await ctx.reply('❌ Gagal membersihkan warnings.');
    }
  } catch (error) {
    logEmitter.emit('log', {
      timestamp: new Date().toISOString(),
      type: 'error',
      text: `clearWarn error: ${error instanceof Error ? error.message : 'Unknown'}`,
    });
  }
}
